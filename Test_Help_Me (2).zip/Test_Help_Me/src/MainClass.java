import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import static java.awt.Color.*;

public class MainClass {
    private JFrame loginFrame;
    private JFrame clientManagementFrame;

    private JFrame frame;
    private JTextField name;
    private JLabel numberL;
    private JTextField number;
    private JLabel timeL;
    private JTextField time;
    private JButton btnDelate;
    private JButton btnUpdate;
    private JButton btnRefresh;
    private JTable table;
    private JScrollPane scrollPane;

    int row;
    ArrayList<Client> clients;
    DefaultTableModel dtm;
    String header[] = new String[] {"Name", "Number", "Time", "Service"};
    private JPanel panel1;
    private JButton button1;


    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MainClass window = new MainClass();
                    window.showLoginPage();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    private void showLoginPage() {
        loginFrame = new JFrame("Login");
        loginFrame.getContentPane().setBackground(LIGHT_GRAY);
        GradientPanel gradientPanel = new GradientPanel(Color.BLUE, new Color(148, 0, 211));
        loginFrame.setContentPane(gradientPanel);
        loginFrame.setBounds(100, 100, 300, 200);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.getContentPane().setLayout(null);
        JLabel lblUsername = new JLabel("Username");
        lblUsername.setBounds(20, 20, 80, 20);
        lblUsername.setForeground(Color.WHITE);
        loginFrame.getContentPane().add(lblUsername);

        JTextField usernameField = new JTextField();
        usernameField.setBounds(110, 20, 150, 20);
        loginFrame.getContentPane().add(usernameField);

        JLabel lblPassword = new JLabel("Password");
        lblPassword.setBounds(20, 50, 80, 20);
        lblPassword.setForeground(Color.WHITE);
        loginFrame.getContentPane().add(lblPassword);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(110, 50, 150, 20);
        loginFrame.getContentPane().add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(110, 80, 80, 20);
        loginFrame.getContentPane().add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (username.equals("admin") && password.equals("admin")) {
                    loginFrame.dispose();
                    showClientManagementPage();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password");
                }
            }
        });
        loginFrame.setVisible(true);
    }
    public void displayStudentDetails() {
        dtm.setRowCount(0);
        for(int i = 0; i < clients.size(); i++) {
            Object[] object = {clients.get(i).name, clients.get(i).number, clients.get(i).time, clients.get(i).service};
            dtm.addRow(object);
        }
    }
    private void showClientManagementPage() {
        clientManagementFrame = new JFrame("Client Management");
        clientManagementFrame.setBounds(100, 100, 700, 450);
        clientManagementFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        clientManagementFrame.getContentPane().setLayout(null);

        frame = new JFrame();
        frame.getContentPane().setBackground(LIGHT_GRAY);
        GradientPanel gradientPanel = new GradientPanel(Color.BLUE, new Color(148, 0, 211));
        frame.setContentPane(gradientPanel);
        frame.setBounds(100, 100, 697, 414);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Name");
        lblNewLabel.setBounds(48, 35, 41, 16);
        lblNewLabel.setForeground(Color.WHITE);
        frame.getContentPane().add(lblNewLabel);

        name = new JTextField();
        name.setBounds(111, 30, 130, 26);
        frame.getContentPane().add(name);
        name.setColumns(10);

        numberL = new JLabel("Number");
        numberL.setBounds(48, 73, 66, 16);
        numberL.setForeground(Color.WHITE);
        frame.getContentPane().add(numberL);

        number = new JTextField();
        number.setColumns(10);
        number.setBounds(111, 68, 130, 26);
        frame.getContentPane().add(number);

        String[] services = {"Hair Coloring", "Hair Styling", "Other Services"};
        JComboBox<String> serviceComboBox = new JComboBox<>(services);
        serviceComboBox.setBounds(95, 140, 150, 26);
        frame.getContentPane().add(serviceComboBox);

        JButton btnNewButton = new JButton("Add");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Client client = new Client(name.getText(), number.getText(), time.getText(), (String) serviceComboBox.getSelectedItem());
                clients.add(client);
                displayStudentDetails();
            }
        });
        btnNewButton.setBounds(48, 167, 87, 26);
        frame.getContentPane().add(btnNewButton);

        timeL = new JLabel("Time");
        timeL.setBounds(48, 107, 66, 16);
        frame.getContentPane().add(timeL);
        timeL.setForeground(Color.WHITE);

        time = new JTextField();
        time.setColumns(10);
        time.setBounds(111, 102, 130, 26);
        frame.getContentPane().add(time);

        btnDelate = new JButton("Delate");
        btnDelate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int choice = JOptionPane.showConfirmDialog(null, "Delete this data?", "Delete", JOptionPane.YES_NO_OPTION);
                if(choice == 0) {
                    dtm.removeRow(row);
                    clients.remove(row);
                    displayStudentDetails();
                }
            }
        });
        btnDelate.setBounds(154, 166, 87, 26);
        frame.getContentPane().add(btnDelate);

        btnUpdate = new JButton("Update");
        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (row >= 0 && row < clients.size()) {
                    clients.get(row).name = name.getText();
                    clients.get(row).number = number.getText();
                    clients.get(row).time = time.getText();
                    displayStudentDetails();
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a row to update.");
                }
            }
        });
        btnUpdate.setBounds(48, 205, 87, 26);
        frame.getContentPane().add(btnUpdate);

        btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                name.setText("");
                number.setText("");
                time.setText("");
            }
        });
        btnRefresh.setBounds(154, 204, 87, 26);
        frame.getContentPane().add(btnRefresh);

        scrollPane = new JScrollPane();
        scrollPane.setBounds(280, 36, 384, 195);
        frame.getContentPane().add(scrollPane);

        table = new JTable();
        dtm = new DefaultTableModel(header,0);
        table.setModel(dtm);
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                row=table.getSelectedRow();
                name.setText(dtm.getValueAt(row, 0).toString());
                number.setText(dtm.getValueAt(row, 1).toString());
                time.setText(dtm.getValueAt(row, 2).toString());
            }
        });
        scrollPane.setViewportView(table);
        frame.setVisible(true);
    }
    public MainClass() {
        clients = new ArrayList<>();
    }
    class GradientPanel extends JPanel {
        private Color startColor;
        private Color endColor;

        public GradientPanel(Color startColor, Color endColor) {
            this.startColor = startColor;
            this.endColor = endColor;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            GradientPaint gradientPaint = new GradientPaint(
                    0, 0, startColor,
                    getWidth(), getHeight(), endColor
            );

            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setPaint(gradientPaint);
            g2d.fillRect(0, 0, getWidth(), getHeight());
            g2d.dispose();
        }
    }
}
