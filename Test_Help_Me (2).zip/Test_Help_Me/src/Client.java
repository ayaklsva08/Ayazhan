
public class Client {
    String name;
    String number;
    String time;
    String service;

    public Client(String name, String number, String time, String service) {
        this.name = name;
        this.number=number;
        this.time=time;
        this.service = service;
    }
}
