public class Main {
    public static void main(String[] args) {
        boolean number;
        int a = 1;
        int b = 2;
        number = a != b;
        System.out.println(number);
    }
}