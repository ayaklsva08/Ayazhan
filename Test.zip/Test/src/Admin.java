import java.util.ArrayList;

public class Admin extends User{
    ArrayList<Worker> workers;
    public Admin(int id, int login, int pwd) {
        super(id, login, pwd);
    }
    public void addWorker(String name, String specialization){
        Worker worker = new Worker(name, specialization);
        if (workers.contains(worker)){
            System.out.println("This worker already exist. Try again!");
        }
        else {
            workers.add(worker);
            System.out.println("Success add worker!");
        }
    }
    public void editWorker(){
        listOfWorkers();
        System.out.println("Type name worker");
        String name = scanner.nextLine();
        for (Worker worker:workers){
            if (name.equals(worker.getName())){
                System.out.println("Type new name of worker:");
                String newName = scanner.nextLine();
                System.out.println("Type new specialization of worker");
                String newSpecialization = scanner.nextLine();
                worker.setName(newName);
                worker.setSpecialization(newSpecialization);
                System.out.println("Success!");
                break;
            }else {
                System.out.println("You Enter wrong value. Try again!");
            }
        }
        String specialization= scanner.nextLine();;
    }
    public void removeWorker(){
        listOfWorkers();
        System.out.println("Type name worker");
        String name = scanner.nextLine();
        for (Worker worker:workers){
            if (name.equals(worker.getName())){
                workers.remove(worker);
                System.out.println("Success!");
            }
            else {
                System.out.println("You enter the wrong value");
            }
        }
    }
    public void listOfWorkers(){
        for (Worker worker : workers){
            System.out.println(worker);
        }
    }
}
