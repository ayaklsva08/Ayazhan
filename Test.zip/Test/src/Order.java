public class Order {
    private int userID;
    private int data;
    private String workerName;

    public Order(int userID, int data, String workerName) {
        this.userID = userID;
        this.data = data;
        this.workerName = workerName;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Order{" +
                "userID=" + userID +
                ", data=" + data +
                '}';
    }
}
