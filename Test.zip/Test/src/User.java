import java.util.ArrayList;
import java.util.Scanner;

public abstract class User {
    static Scanner scanner;
    private int id;
    private int login;
    private int pwd;

    ArrayList<Order> orders;

    public User(int id, int login, int pwd) {
        this.id = id;
        this.login = login;
        this.pwd = pwd;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLogin() {
        return login;
    }

    public void setLogin(int login) {
        this.login = login;
    }

    public int getPwd() {
        return pwd;
    }

    public void setPwd(int pwd) {
        this.pwd = pwd;
    }
    public void addOrder(){
        System.out.println("Enter the user id:");
        int id = scanner.nextInt();
        System.out.println("Enter the worker name:");
        String name = scanner.nextLine();
        System.out.println("Enter the data:");
        int data = scanner.nextInt();
        Order order = new Order(user.id,data);
        orders.add(order);
        System.out.println(user.getLogin()+ " Success add order " +order.getData() );
    }
    public void removeOrder(User user){
        System.out.println("Enter User id:");
        int id = scanner.nextInt();
        System.out.println("Enter the data:");
        int data = scanner.nextInt();
        Order order = new Order(id,data);
        if(orders.contains(order)){
            orders.remove(order);
            System.out.println(user.getLogin()+ " Success remove order");
        }
        else {
            System.out.println("This order do no exist");
        }
    }
    public void EditOrder(User user){
        System.out.println("Enter user id:");
        int id = scanner.nextInt();
        System.out.println("Enter date of order:");
        int date = scanner.nextInt();
        for (Order order : orders){
            if (id == order.getUserID() && date == order.getData()){
                System.out.println("enter the new Date: ");
                int newDate = scanner.nextInt();
                order.setData(newDate);
            }else {
                System.out.println("You enter wrong value. Try again!");
            }
        }
        System.out.println(user.getLogin()+ " Success edit order");
    }
    public void listOfOrders(){
        for (Order order:orders){
            System.out.println(order);
        }
    }
}
