import java.util.ArrayList;

public class Client extends User{
    public Client(int id, int login, int pwd) {
        super(id, login, pwd);
    }
    ArrayList<Client> clients;
}
