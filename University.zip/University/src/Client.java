
public class Client {
    String name;
    String number;
    String time;
    
    public Client(String name, String number, String time) {
    	this.name = name;
    	this.number=number;
    	this.time=time;
    }
}
